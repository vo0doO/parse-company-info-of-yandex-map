'''
import requests
from bs4 import BeautifulSoup

with open(file = "D:/PYTOHN-PROJECT/curiosity/curiosity/yandex.html", mode = "r") as f:
	text = f.read()
soup = BeautifulSoup(text, 'lxml')
imtems = soup.find_all('div', {'class': ''})
'''
import logging
import requests
import re
import json
from bs4 import BeautifulSoup

filename = "D:/PYTOHN-PROJECT/yandex/yandex/yandex.html"

def read_file(filename):
	with open(file = filename, mode = "r+b") as f:
		text = f.read(decoding_table, 'decoding_table'))
	return text

results = []
def parse_company_links():

	text = read_file(filename)
	
	soup = BeautifulSoup(text, 'lxml')
	items = soup.find_all('a', {'class': 'search-business-snippet-view'})
	assert isinstance(items, soup)
	print(soup)
	print(items)
	for item in items:
		href = item.get('href')
		results.append(str('http://yandex.com' + href))
	return results
parse_company_links()
print(results)