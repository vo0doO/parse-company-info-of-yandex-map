import pyrebase


config = {
    "apiKey": "AIzaSyD6EzxDobegHGvkorLEle6OBt_RNedkD0g",
    "authDomain": "project-3931781304531690229.firebaseapp.com",
    "databaseURL": "https://project-3931781304531690229.firebaseio.com",
    "projectId": "project-3931781304531690229",
    "storageBucket": "project-3931781304531690229.appspot.com",
    "serviceAccount": "/home/ubuntu/workspace/yandex-to-vk/kirsanov-dot-com-fa36c163c326.json"
  }

firebase = firebase.initializeApp(config);